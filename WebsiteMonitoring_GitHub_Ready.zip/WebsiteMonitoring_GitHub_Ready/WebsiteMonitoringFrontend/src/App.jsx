import { useEffect, useState } from 'react'
import './App.css'
import icon from './assets/icon.png'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts'

function App() {

  const [websites, setWebsites] = useState([])

  const [summary, setSummary] = useState({
    totalWebsites: 0,
    onlineWebsites: 0,
    offlineWebsites: 0,
    averageResponseTime: 0
  })

  const [recentChecks, setRecentChecks] = useState([])

  const [lastUpdate, setLastUpdate] = useState(null)

  const [openMenuId, setOpenMenuId] = useState(null)

  const [historyData, setHistoryData] = useState([])

  const chartColors = [
    '#2563eb',
    '#16a34a',
    '#dc2626',
    '#f59e0b',
    '#7c3aed',
    '#0891b2',
    '#db2777',
    '#65a30d'
  ]

  const chartData = []

  const maxChecks = 10

  for (let i = maxChecks - 1; i >= 0; i--) {
    const point = {}

    historyData.forEach(({ website, checks }) => {
      const check = checks[i]

      if (check && check.responseTime >= 0) {
        point.time = new Date(check.checkedAt).toLocaleTimeString('pt-PT', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        })

        point[website.name] = check.responseTime
      }
    })

    if (Object.keys(point).length > 1) {
      chartData.push(point)
    }
  }

  const [showAddForm, setShowAddForm] = useState(false)

  const [addError, setAddError] = useState('')

  const [newWebsite, setNewWebsite] = useState({
    name: '',
    url: ''
  })


  //ADD WEBSITE
//ADD WEBSITE
const addWebsite = () => {
  setAddError('')

  if (!newWebsite.name.trim()) {
    setAddError('Please enter a website name.')
    return
  }

  if (
    !newWebsite.url.startsWith('http://') &&
    !newWebsite.url.startsWith('https://')
  ) {
    setAddError(
      'Please enter a valid URL starting with http:// or https://'
    )
    return
  }

  const duplicatedWebsite = websites.some((website) =>
    website.url.toLowerCase() === newWebsite.url.toLowerCase()
  )

  if (duplicatedWebsite) {
    setAddError('This website is already registered.')
    return
  }

  fetch('http://localhost:8080/api/websites', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(newWebsite)
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error('Unable to add this website.')
      }

      return fetch('http://localhost:8080/api/websites/status')
    })
    .then((response) => response.json())
    .then((data) => {
      setWebsites(data)

      setNewWebsite({
        name: '',
        url: ''
      })

      setAddError('')
      setShowAddForm(false)
    })
    .catch(() => {
      setAddError(
        'Unable to add this website. Please check the details and try again.'
      )
    })
}


//STATUS
useEffect(() => {

  const loadWebsites = () => {
    fetch('http://localhost:8080/api/websites/status')
      .then(response => response.json())
      .then(data => setWebsites(data))
      .catch(error => console.error('Error loading websites:', error))
  }

  loadWebsites()

  const interval = setInterval(() => {
    loadWebsites()
  }, 10000)

  return () => {
    clearInterval(interval)
  }

}, [])


//DASHBOARD DATA
useEffect(() => {

  const loadDashboardData = () => {

    //SUMMARY
    fetch('http://localhost:8080/api/websites/dashboard/summary')
      .then(response => response.json())
      .then(data => {
        setSummary(data)
        setLastUpdate(new Date())
      })
      .catch(error =>
        console.error('Error loading summary:', error)
      )


    //RECENT CHECKS
    fetch('http://localhost:8080/api/websites/health-checks/recent')
      .then(response => response.json())
      .then(data => setRecentChecks(data))
      .catch(error =>
        console.error('Error loading recent checks:', error)
      )

  }


  loadDashboardData()


  const interval = setInterval(() => {
    loadDashboardData()
  }, 10000)


  return () => {
    clearInterval(interval)
  }

}, [])


  //RESPONSE TIME TABLE
  useEffect(() => {
    if (websites.length === 0) return

    Promise.all(
      websites.map((website) =>
        fetch(`http://localhost:8080/api/websites/${website.id}/health-checks`)
          .then(response => response.json())
          .then(checks => ({
            website,
            checks
          }))
      )
    )
      .then(data => setHistoryData(data))
      .catch(error => console.error('Error loading history:', error))
  }, [websites])


  //DELETE WEBSITE
  const deleteWebsite = (id) => {
    fetch(`http://localhost:8080/api/websites/${id}`, {
      method: 'DELETE'
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error('Error deleting website')
        }

        setWebsites((currentWebsites) =>
          currentWebsites.filter((website) => website.id !== id)
        )

        setOpenMenuId(null)
      })
      .catch((error) => {
        console.error('Error deleting website:', error)
      })
  }


  return (
    <div className="app">

      <aside className="sidebar">

        <div className="logo-area">
          <div className="logo-icon">
            <img src={icon} alt="Website Monitor" />
          </div>

          <h2>Website Monitor</h2>
        </div>

        <nav className="menu">
          <button className="menu-item">Dashboard</button>
          <button className="menu-item">Websites</button>
          <button className="menu-item">Add Website</button>
          <button className="menu-item">History</button>
          <button className="menu-item">Settings</button>
        </nav>

        <div className="dark-mode">
          Dark mode
        </div>

      </aside>


      <main className="main-content">

        <header className="topbar">
          <h1>Dashboard</h1>

          <span>
            Last update:{' '}
            {lastUpdate
              ? lastUpdate.toLocaleTimeString('pt-PT')
              : '--:--:--'}
          </span>
        </header>


        <section className="summary-grid">

          <div className="summary-card">
            <p>Total Websites</p>
            <h2>{summary.totalWebsites}</h2>
            <span>Registered websites</span>
          </div>

          <div className="summary-card">
            <p>Online</p>
            <h2>{summary.onlineWebsites}</h2>
            <span>Websites online</span>
          </div>

          <div className="summary-card">
            <p>Offline</p>
            <h2>{summary.offlineWebsites}</h2>
            <span>Websites offline</span>
          </div>

          <div className="summary-card">
            <p>Avg Response Time</p>
            <h2>{summary.averageResponseTime} ms</h2>
            <span>Average response time</span>
          </div>

        </section>


        <section className="dashboard-grid">

          <div className="panel websites-panel">

            <h3>Websites</h3>

            <table>

              <thead>
                <tr>
                  <th>Name</th>
                  <th>URL</th>
                  <th>Status</th>
                  <th>Response Time</th>
                  <th>Last Check</th>
                  <th></th>
                </tr>
              </thead>

              <tbody>

                {websites.length === 0 ? (

                  <tr>
                    <td>No websites yet</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td>-</td>
                    <td></td>
                  </tr>

                ) : (

                  websites.map((website) => (

                    <tr key={website.id}>

                      <td>
                        <img
                          src={`https://www.google.com/s2/favicons?domain=${website.url}&sz=64`}
                          alt={website.name}
                          width="20"
                          height="20"
                        />

                        {' '}
                        {website.name}
                      </td>

                      <td>{website.url}</td>

                      <td>
                        <span
                          className={`status-badge ${website.status.toLowerCase()}`}
                        >
                          {website.status}
                        </span>
                      </td>

                      <td>
                        {website.responseTime} ms
                      </td>

                      <td>
                        {website.lastCheck}
                      </td>

                      <td className="actions-cell">

                        <div
                          className="actions-menu"
                          onMouseLeave={() => setOpenMenuId(null)}
                        >

                          <button
                            className="more-button"
                            onClick={() => setOpenMenuId(website.id)}
                          >
                            ⋮
                          </button>

                          {openMenuId === website.id && (

                            <div className="website-menu">

                              <button
                                className="delete-option"
                                onClick={() => deleteWebsite(website.id)}
                              >
                                Delete Website
                              </button>

                            </div>

                          )}

                        </div>

                      </td>

                    </tr>

                  ))

                )}

              </tbody>

            </table>


            <button
              className="add-button"
              onClick={() => {
                setAddError('')
                setShowAddForm(true)
              }}
            >
              + Add Website
            </button>


            {showAddForm && (

              <div className="modal-overlay">

                <div className="add-modal">

                  <button
                    className="modal-close"
                    onClick={() => {
                      setAddError('')
                      setShowAddForm(false)
                    }}
                  >
                    ×
                  </button>

                  <h2>Add Website</h2>


                  <label>
                    Website Name
                  </label>

                  <input
                    type="text"
                    placeholder="Google"
                    value={newWebsite.name}
                    onChange={(e) =>
                      setNewWebsite({
                        ...newWebsite,
                        name: e.target.value
                      })
                    }
                  />


                  <label>
                    Website URL
                  </label>

                  <input
                    type="text"
                    placeholder="https://www.google.com"
                    value={newWebsite.url}
                    onChange={(e) =>
                      setNewWebsite({
                        ...newWebsite,
                        url: e.target.value
                      })
                    }
                  />


                  {addError && (

                    <div className="form-error">

                      <strong>
                        {addError}
                      </strong>

                      <span>
                        Check the website name and make sure the URL starts with https://
                      </span>

                    </div>

                  )}


                  <div className="modal-buttons">

                    <button
                      className="cancel-button"
                      onClick={() => {
                        setAddError('')
                        setShowAddForm(false)
                      }}
                    >
                      Cancel
                    </button>

                    <button
                      className="save-button"
                      onClick={addWebsite}
                    >
                      Add Website
                    </button>

                  </div>

                </div>

              </div>

            )}

          </div>


          <div className="panel recent-panel">

            <h3>Recent Checks</h3>

            {recentChecks.length === 0 ? (

              <p>No checks yet.</p>

            ) : (

              recentChecks
                .slice(0, 5)
                .map((check) => (

                  <div key={check.id}>

                    <strong>
                      {check.website.name}
                    </strong>

                    <br />

                    Status: {check.statusCode}

                    <br />

                    Response: {check.responseTime} ms

                    <hr />

                  </div>

                ))

            )}

          </div>

        </section>


        <section className="panel chart-panel">

          <h3>
            Response Time (ms)
          </h3>

          <div className="chart-placeholder">

            <ResponsiveContainer
              width="100%"
              height={250}
            >

              <LineChart data={chartData}>

                <CartesianGrid
                  strokeDasharray="3 3"
                />

                <XAxis
                  dataKey="time"
                  interval="preserveStartEnd"
                />

                <YAxis
                  domain={[0, 'auto']}
                />

                <Tooltip />

                <Legend />

                {historyData.map(
                  ({ website }, index) => (

                    <Line
                      key={website.id}
                      type="monotone"
                      dataKey={website.name}
                      name={website.name}
                      stroke={
                        chartColors[
                          index % chartColors.length
                        ]
                      }
                      strokeWidth={2}
                      dot={true}
                    />

                  )
                )}

              </LineChart>

            </ResponsiveContainer>

          </div>

        </section>

      </main>

    </div>
  )
}

export default App