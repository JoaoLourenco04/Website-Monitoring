# Website Monitoring System

A full-stack web application for monitoring website availability and performance.

This project was independently developed during my Full-Stack Development internship at TSS Ciberseguridad. The application performs website health checks, records HTTP status and response times, stores monitoring history, and provides a React interface for viewing monitoring data.

## Features

- Add, edit and remove monitored websites
- Manual and scheduled website health checks
- Online, Offline and Unknown status tracking
- HTTP status and response-time monitoring
- Monitoring history and dashboard summaries
- REST API connecting the backend and frontend
- Persistent storage with MySQL

## Tech Stack

### Backend
- Java 21
- Spring Boot 3
- Spring Data JPA
- Hibernate
- MySQL
- Gradle

### Frontend
- React
- JavaScript
- HTML5
- CSS3
- Recharts
- Vite

## Project Structure

```text
WebsiteMonitoring/
├── src/                         # Spring Boot backend
├── WebsiteMonitoringFrontend/  # React frontend
├── gradle/                      # Gradle wrapper files
├── build.gradle
├── settings.gradle
├── gradlew
├── gradlew.bat
└── README.md
```

## Running the Project

### Backend

1. Create a MySQL database named `website_monitoring`.
2. Configure the database connection in `src/main/resources/application.properties` if your local credentials differ from the defaults.
3. Start the Spring Boot application:

```bash
./gradlew bootRun
```

On Windows:

```bash
gradlew.bat bootRun
```

### Frontend

```bash
cd WebsiteMonitoringFrontend
npm install
npm run dev
```

## Author

**João Lourenço**

LinkedIn: https://www.linkedin.com/in/jo%C3%A3o-louren%C3%A7o-41762b254/
