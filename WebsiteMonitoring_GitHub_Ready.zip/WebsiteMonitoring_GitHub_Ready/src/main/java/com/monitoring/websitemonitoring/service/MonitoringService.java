package com.monitoring.websitemonitoring.service;

import com.monitoring.websitemonitoring.repository.HealthCheckRepository;
import com.monitoring.websitemonitoring.model.HealthCheck;
import com.monitoring.websitemonitoring.model.Website;
import com.monitoring.websitemonitoring.repository.WebsiteRepository;
import org.springframework.stereotype.Service;
import org.springframework.scheduling.annotation.Scheduled;

import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;
import java.time.Duration;
import java.time.LocalDateTime;

import java.util.List;



@Service
public class MonitoringService  {




    private final HealthCheckRepository healthCheckRepository;

    private final WebsiteRepository websiteRepository;

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    public MonitoringService(
            HealthCheckRepository healthCheckRepository,
            WebsiteRepository websiteRepository
    ) {
        this.healthCheckRepository = healthCheckRepository;
        this.websiteRepository = websiteRepository;
    }

    public void checkWebsite(Website website) {
        HealthCheck healthCheck = new HealthCheck();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(website.getUrl()))
                .timeout(Duration.ofSeconds(15))
                .header("User-Agent", "WebsiteMonitoringSystem/1.0")
                .GET()
                .build();

        try {
            long startTime = System.currentTimeMillis();

            HttpResponse<String> response = httpClient.send(
                    request,
                    HttpResponse.BodyHandlers.ofString()
            );

            long endTime = System.currentTimeMillis();

            long responseTime = endTime - startTime;

            healthCheck.setResponseTime(responseTime);

            healthCheck.setStatusCode(response.statusCode());

            healthCheck.setCheckedAt(LocalDateTime.now());

            healthCheck.setWebsite(website);

            healthCheckRepository.save(healthCheck);

        } catch (Exception e) {

            healthCheck.setStatusCode(0);
            healthCheck.setResponseTime(-1);
            healthCheck.setCheckedAt(LocalDateTime.now());
            healthCheck.setWebsite(website) ;

            healthCheckRepository.save(healthCheck);

            e.printStackTrace();

        }
    }

    public void checkAllWebsites() {

        List<Website> websites = websiteRepository.findAll();
        for (Website website : websites) {
            checkWebsite(website);
        }
    }

    @Scheduled(fixedRateString = "${monitoring.interval}")
    public void scheduledWebsiteCheck() {
        checkAllWebsites();
    }
}
