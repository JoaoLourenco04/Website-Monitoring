package com.monitoring.websitemonitoring.controller;

import com.monitoring.websitemonitoring.model.Website;
import com.monitoring.websitemonitoring.service.WebsiteService;
import org.springframework.web.bind.annotation.*;
import com.monitoring.websitemonitoring.model.HealthCheck;
import com.monitoring.websitemonitoring.model.WebsiteStatus;
import com.monitoring.websitemonitoring.model.DashboardSummary;
import jakarta.validation.Valid;

import java.util.List;

@RestController
@RequestMapping("/api/websites")
@CrossOrigin(origins = "http://localhost:5173")
public class WebsiteController {

    private WebsiteService websiteService;

    public WebsiteController(WebsiteService websiteService) {
        this.websiteService = websiteService;
    }

    @PostMapping
    public Website createWebsite(@Valid @RequestBody Website website) {
        return websiteService.saveWebsite(website);
    }

    @GetMapping
    public List<Website> getAllWebsites() {
        return websiteService.getAllWebsites();
    }

    @GetMapping("/{id}/health-checks")
    public List<HealthCheck> getWebsiteHealthChecks(@PathVariable long id) {
        return websiteService.getWebsiteHealthChecks(id);
    }

    @GetMapping("/{id}")
    public Website getWebsiteById(@PathVariable long id) {
        return websiteService.getWebsiteById(id);
    }

    @PutMapping("/{id}")
    public Website updateWebsite(
            @PathVariable long id,
            @Valid @RequestBody Website website
    ) {
        return websiteService.updateWebsite(id, website);
    }

    @DeleteMapping("/{id}")
    public void deleteWebsite(@PathVariable long id) {
        websiteService.deleteWebsite(id);
    }

    @GetMapping("/status")
    public List<WebsiteStatus> getAllWebsiteStatuses() {
        return websiteService.getAllWebsiteStatuses();
    }

    @GetMapping("/dashboard/summary")
    public DashboardSummary getDashboardSummary() {
        return websiteService.getDashboardSummary();
    }

    @GetMapping("/health-checks/recent")
    public List<HealthCheck> getRecentHealthChecks() {
        return websiteService.getRecentHealthChecks();
    }

}
