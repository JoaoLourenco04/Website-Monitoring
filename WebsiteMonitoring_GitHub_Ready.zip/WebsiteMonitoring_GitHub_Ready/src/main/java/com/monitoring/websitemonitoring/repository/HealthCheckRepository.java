package com.monitoring.websitemonitoring.repository;

import com.monitoring.websitemonitoring.model.HealthCheck;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;


public interface HealthCheckRepository extends JpaRepository<HealthCheck, Long> {

    List<HealthCheck> findByWebsiteIdOrderByCheckedAtDesc(Long websiteId);

    HealthCheck findTopByWebsiteIdOrderByCheckedAtDesc(Long websiteId);

    List<HealthCheck> findTop10ByOrderByCheckedAtDesc();

    void deleteByWebsiteId(Long websiteId);

}
