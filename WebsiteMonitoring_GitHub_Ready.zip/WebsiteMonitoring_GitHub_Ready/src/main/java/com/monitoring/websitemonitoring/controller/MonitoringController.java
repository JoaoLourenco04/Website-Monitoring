package com.monitoring.websitemonitoring.controller;

import com.monitoring.websitemonitoring.model.Website;
import com.monitoring.websitemonitoring.service.MonitoringService;
import com.monitoring.websitemonitoring.service.WebsiteService;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/monitor")
public class MonitoringController {

    private MonitoringService monitoringService;
    private WebsiteService websiteService;

    public MonitoringController(
            MonitoringService monitoringService,
            WebsiteService websiteService
    ) {
        this.monitoringService = monitoringService;
        this.websiteService = websiteService;
    }

    @PostMapping("/{id}")
    public String monitorWebsite(@PathVariable long id) {

        Website website = websiteService.getWebsiteById(id);

        monitoringService.checkWebsite(website);

        return "website monitored successfully";
    }

    @PostMapping("/all")
    public String monitorAllWebsites() {

        monitoringService.checkAllWebsites();

        return "all websites have been monitored successfully";
    }


}
