package com.monitoring.websitemonitoring.model;

import java.time.LocalDateTime;

public class WebsiteStatus {

    private Long id;
    private String name;
    private String url;
    private String status;
    private int statusCode;
    private long responseTime;
    private LocalDateTime lastCheck;

    public WebsiteStatus(
            Long id,
            String name,
            String url,
            String status,
            int statusCode,
            long responseTime,
            LocalDateTime lastCheck
    ) {
        this.id = id;
        this.name = name;
        this.url = url;
        this.status = status;
        this.statusCode = statusCode;
        this.responseTime = responseTime;
        this.lastCheck = lastCheck;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getUrl() {
        return url;
    }

    public String getStatus() {
        return status;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public long getResponseTime() {
        return responseTime;
    }

    public LocalDateTime getLastCheck() {
        return lastCheck;
    }
}