package com.monitoring.websitemonitoring.service;

import com.monitoring.websitemonitoring.model.Website;
import com.monitoring.websitemonitoring.model.HealthCheck;
import com.monitoring.websitemonitoring.repository.HealthCheckRepository;
import com.monitoring.websitemonitoring.repository.WebsiteRepository;
import com.monitoring.websitemonitoring.model.WebsiteStatus;
import com.monitoring.websitemonitoring.model.DashboardSummary;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class WebsiteService {

    private final WebsiteRepository websiteRepository;

    private final HealthCheckRepository healthCheckRepository;

    public WebsiteService(WebsiteRepository websiteRepository, HealthCheckRepository healthCheckRepository) {
        this.websiteRepository = websiteRepository;
        this.healthCheckRepository = healthCheckRepository;
    }

    public List<HealthCheck> getWebsiteHealthChecks(long websiteId) {
        return healthCheckRepository.findByWebsiteIdOrderByCheckedAtDesc(websiteId);
    }

    public Website saveWebsite(Website website) {
        return websiteRepository.save(website);
    }

    public List<Website> getAllWebsites() {
        return websiteRepository.findAll();
    }

    public Website getWebsiteById(long id) {
        return websiteRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Website not found"
                ));
    }

    public Website updateWebsite(long id, Website updatedWebsite) {

        Website existingWebsite = websiteRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND,
                        "Website not found"
                ));

        existingWebsite.setName(updatedWebsite.getName());
        existingWebsite.setUrl(updatedWebsite.getUrl());

        return websiteRepository.save(existingWebsite);
    }

    @Transactional
    public void deleteWebsite(long id) {

        if (!websiteRepository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Website not found"
            );
        }

        healthCheckRepository.deleteByWebsiteId(id);
        websiteRepository.deleteById(id);
    }

    public List<WebsiteStatus> getAllWebsiteStatuses() {

        List<Website> websites = websiteRepository.findAll();

        return websites.stream().map(website -> {

            HealthCheck latestCheck =
                    healthCheckRepository.findTopByWebsiteIdOrderByCheckedAtDesc(website.getId());

            if (latestCheck == null) {
                return new WebsiteStatus(
                        website.getId(),
                        website.getName(),
                        website.getUrl(),
                        "Unknown",
                        0,
                        -1,
                        null
                );
            }

            String status =
                    latestCheck.getStatusCode() >= 200 && latestCheck.getStatusCode() < 400
                            ? "Online"
                            : "Offline";

            return new WebsiteStatus(
                    website.getId(),
                    website.getName(),
                    website.getUrl(),
                    status,
                    latestCheck.getStatusCode(),
                    latestCheck.getResponseTime(),
                    latestCheck.getCheckedAt()
            );

        }).toList();
    }

    public DashboardSummary getDashboardSummary() {

        List<WebsiteStatus> statuses = getAllWebsiteStatuses();

        long totalWebsites = statuses.size();

        long onlineWebsites = statuses.stream()
                .filter(status -> "Online".equals(status.getStatus()))
                .count();

        long offlineWebsites = statuses.stream()
                .filter(status -> "Offline".equals(status.getStatus()))
                .count();

        long averageResponseTime = (long) statuses.stream()
                .filter(status -> status.getResponseTime() >= 0)
                .mapToLong(WebsiteStatus::getResponseTime)
                .average()
                .orElse(0);

        return new DashboardSummary(
                totalWebsites,
                onlineWebsites,
                offlineWebsites,
                averageResponseTime
        );
    }

    public List<HealthCheck> getRecentHealthChecks() {
        return healthCheckRepository.findTop10ByOrderByCheckedAtDesc();
    }



}

