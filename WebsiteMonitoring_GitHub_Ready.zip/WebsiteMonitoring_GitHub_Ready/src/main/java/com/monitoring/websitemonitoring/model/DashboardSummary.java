package com.monitoring.websitemonitoring.model;

public class DashboardSummary {

    private long totalWebsites;
    private long onlineWebsites;
    private long offlineWebsites;
    private long averageResponseTime;

    public DashboardSummary(
            long totalWebsites,
            long onlineWebsites,
            long offlineWebsites,
            long averageResponseTime
    ) {
        this.totalWebsites = totalWebsites;
        this.onlineWebsites = onlineWebsites;
        this.offlineWebsites = offlineWebsites;
        this.averageResponseTime = averageResponseTime;
    }

    public long getTotalWebsites() {
        return totalWebsites;
    }

    public long getOnlineWebsites() {
        return onlineWebsites;
    }

    public long getOfflineWebsites() {
        return offlineWebsites;
    }

    public long getAverageResponseTime() {
        return averageResponseTime;
    }
}