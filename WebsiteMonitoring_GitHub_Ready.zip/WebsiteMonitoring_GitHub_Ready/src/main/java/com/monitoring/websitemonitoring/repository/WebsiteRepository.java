package com.monitoring.websitemonitoring.repository;

import com.monitoring.websitemonitoring.model.Website;
import org.springframework.data.jpa.repository.JpaRepository;


public interface WebsiteRepository extends JpaRepository<Website, Long> {



}
