package com.monitoring.websitemonitoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebsiteMonitoringApplicationTests {

    @Test
    void contextLoads() {
    }

}
